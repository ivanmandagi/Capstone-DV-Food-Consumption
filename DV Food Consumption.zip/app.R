library(readxl)
library(dplyr)
library(shiny)
library(shinydashboard)
library(flexdashboard)
library(lubridate) # manipulasi tanggal
library(ggthemes) # tema tambahan ggplot
library(tidyverse) # praproses data
library(plotly)  # membuat visualisasi  interaktif
library(scales) # mengatur tampilan skala pada plot
library(glue) # mengatur tooltip di plotly
library(rsconnect)
library(DT)
library(xtable)


food %>% 
    mutate_at(vars(`(A1) CITY`, `(B3) GENDER`, `(B6) ETHNIC`), as.factor)

header <- dashboardHeader(
    title = "Food Consumption")


sidebar <- dashboardSidebar(
    collapsed = F,
    sidebarMenu(
        menuItem(
            text = "Data Overview",
            tabName = "Overview",
            icon = icon("usd", lib = "glyphicon")
        ),
        menuItem(
            text = "Food & Religion",
            tabName = "FnR",
            icon = icon("heart", lib = "glyphicon")
        ),
        menuItem(
            text = "Data Source",
            tabName = "Data",
            icon = icon("star", lib = "glyphicon")
        ),
        menuItem("Source Code", icon = icon("file-code-o"), 
                 href = "http://bca.co.id")
    )
)

body <- dashboardBody(
    tabItems(
        
        # TAB 1  
        
        tabItem(
            tabName = "Overview",
            fluidPage(
    h2(tags$b("Food Consumption in Indonesia")),
    br(),
    div(style = "text-align:justify", 
        p("Food consumption is a periodic behavior. It is triggered at various moments of the day by a number of converging factors 
          (time of day, need state, sensory stimulation, social context, religious believe, etc).", 
          "The growing food consumption demand in Indonesia has provided serious challenges for food policy which will have an impact in the years to come.",
          "Existing policies to increase the production of staple foods such as rice, maize and soybeans (Upsus Pajale) may not be adequate to meet increasing food demand. A growing population and middle class in Indonesia, and a high rate of 
          urbanization have led to changes in the dietary patterns and food demand of the future. Higher incomes and better 
          knowledge tend to make consumers demand healthier and more diversified food."),
        br()
    )
), 
fluidPage(
    tabBox(width = 12,
           title = tags$b("Health Factor Consideration in Food Consumption"),
           id = "tabset1",
           side = "right",
           tabPanel(tags$b("Education"), 
                    plotlyOutput("plot1")
           ),
           tabPanel(tags$b("Social Class"), 
                    plotlyOutput("plot2")
           ),
           tabPanel(tags$b("Ethnic"), 
                    plotlyOutput("plot3")
           )),
        infoBox("Total Food Consumption", 
                 "710 data", 
                 icon = icon("city"),
                 color = "maroon"),
        
        infoBox("Period of Data",
                 "as of Mei 31, 2021",
                 icon = icon("tree"),
                 color = "green"),
        
) #TUTUP FLUID PAGE
), #TUTUP TAB ITEM
    
    #TAB 2
  
    tabItem(
            tabName = "FnR",
            fluidPage(
                h2(tags$b("Food and Religious Analytics")),
                br(),
                div(style = "text-align:justify", 
                    p("Food consumption is a periodic behavior. It is triggered at various moments of the day by a number of converging factors 
          (time of day, need state, sensory stimulation, social context, religious believe, etc).", 
                      "The growing food consumption demand in Indonesia has provided serious challenges for food policy which will have an impact in the years to come.",
                      "Existing policies to increase the production of staple foods such as rice, maize and soybeans (Upsus Pajale) may not be adequate to meet increasing food demand. A growing population and middle class in Indonesia, and a high rate of 
          urbanization have led to changes in the dietary patterns and food demand of the future. Higher incomes and better 
          knowledge tend to make consumers demand healthier and more diversified food."),
                    br()
                )
            ), 
            fluidPage(
                tabBox(width = 12,
                       title = tags$b("Monthly Expenditures"),
                       id = "tabset1",
                       side = "right",
                       tabPanel(tags$b("Social Class"), 
                                plotlyOutput("plot4")
                       ),
                       tabPanel(tags$b("Education Level"), 
                                plotlyOutput("plot5")
                       )
                       )
                ),
            
            fluidPage(
                tabBox(width = 12,
                       title = tags$b("Religious Value in type of Food"),
                       id = "tabset1",
                       side = "right",
                       tabPanel(tags$b("Religion"), 
                                plotlyOutput("plot6")
                       ),
                       tabPanel(tags$b("Education Level"), 
                                plotlyOutput("plot7")
                       )
            
                )
            )
  ), # TUTUP TAB ITEM

    #TAB 3

    tabItem(
        tabName = "Data",
        h2(tags$b("Food Consumption")),
        DT::dataTableOutput("table1")
    )

 ) # TUTUP TAB ITEMS
) # TUTUP DASHBOARD BODY


ui <- dashboardPage(
    header = header,
    body = body,
    sidebar = sidebar,
    skin = "green")
    

server <- function(input, output) {
    output$plot1 <- renderPlotly({
        
        eduhealth <- food %>%
            select(`(B7) EDUCATION LEVEL`, `(D16) HEALTH FACTOR`) %>%
            group_by(`(B7) EDUCATION LEVEL`, `(D16) HEALTH FACTOR`) %>% 
            summarise(freq = n())
        
        plotedu <- ggplot(eduhealth, aes(x = `(D16) HEALTH FACTOR`, 
                                       text = glue("Jumlah : {freq}}"))) + 
            geom_bar(aes(fill= `(B7) EDUCATION LEVEL`)) + 
            labs(title = "Health Factor on Education Level", x = "Education Level") +
            theme(legend.title = element_blank())
        
        ggplotly(plotedu, tooltip = "text")
    
    }) 
    
    output$plot2 <- renderPlotly({
        
        socialhealth <- food %>%
            select(`(B10) SOCIAL CLAS`, `(D16) HEALTH FACTOR`) %>%
            group_by(`(B10) SOCIAL CLAS`, `(D16) HEALTH FACTOR`) %>% 
            summarise(freq = n())
        
        plotsocio <- ggplot(socialhealth, aes(x = `(D16) HEALTH FACTOR`, 
                                              text = glue("Jumlah : {freq}}"))) + 
            geom_bar(aes(fill= `(B10) SOCIAL CLAS`)) + 
            labs(title = "Health Factor On Social Status", x = "Social Class") +
            theme(legend.title = element_blank())
        
        ggplotly(plotsocio, tooltip = "text")
        
    })
    
    output$plot3 <- renderPlotly({
        
        ethnic <- food %>% 
            select(`(B6) ETHNIC`, `(B3) GENDER`) %>% 
            group_by(`(B6) ETHNIC`) %>% 
            summarise(freq = n())
        
        plotSuku <- ggplot(ethnic, aes(x = reorder(`(B6) ETHNIC`, -freq),
                                       y = freq, 
                                       text = glue("Suku : {`(B6) ETHNIC`}
                               Jumlah : {freq}"))) +
            geom_col(fill = rainbow(8)) +
            labs(x = "Suku",
                 y = NULL, 
                 title = "Health Cionsumption based on Ethnic") + 
            theme_minimal()
        
        ggplotly(plotSuku, tooltip = "text")
        
    })
    
    output$plot4 <- renderPlotly({
        
        socialexpand <- food %>%
            select(`(B10) SOCIAL CLAS`, `(C15) % MONTHLY EXPENDITURE FOR FOOD`) %>%
            group_by(`(B10) SOCIAL CLAS`, `(C15) % MONTHLY EXPENDITURE FOR FOOD`)
        
        plotd<- ggplot(socialexpand, aes(x=`(B10) SOCIAL CLAS`, y=`(C15) % MONTHLY EXPENDITURE FOR FOOD`, 
                                         text = glue("Pendidikan : {`(B10) SOCIAL CLAS`} 
                                        Persentase : {`(C15) % MONTHLY EXPENDITURE FOR FOOD`}"))) +
            geom_point(position = "identity", col = "darkslategray3") +
            labs(title = "% Monthly Expenditure on Social Class",
                 x= "Social Class",
                 y= "% Monthly Expenditure for Food") 
        ggplotly(plotd, tooltip = "text")
        
    })
    
    output$plot5 <- renderPlotly({
        
        eduexpand <- food %>%
            select(`(B7) EDUCATION LEVEL`, `(C15) % MONTHLY EXPENDITURE FOR FOOD`) %>%
            group_by(`(B7) EDUCATION LEVEL`, `(C15) % MONTHLY EXPENDITURE FOR FOOD`)
        
        plote <- ggplot(eduexpand, aes(x=`(B7) EDUCATION LEVEL`, y=`(C15) % MONTHLY EXPENDITURE FOR FOOD`, 
                                       text = glue("Pendidikan : {`(B7) EDUCATION LEVEL`} 
                                        Persentase : {`(C15) % MONTHLY EXPENDITURE FOR FOOD`}"))) +
            geom_point(position = "identity", col = "red") +
            labs(title = "% Monthly Expenditure on Education Level",
                 x= "Education Level",
                 y= "% Monthly Expenditure for Food")
        
        ggplotly(plote, tooltip = "text")
        
    })
    
    output$plot6 <- renderPlotly({
        
        foodreli <- food %>%
            select(`(B5) RELIGION`,`(E18) RELIGIOUS VALUE IN TYPE OF FOOD`) %>%
            group_by(`(B5) RELIGION`, `(E18) RELIGIOUS VALUE IN TYPE OF FOOD`) %>% 
            summarise(freq = n())
        
        plotf <- ggplot(foodreli, aes(x= `(E18) RELIGIOUS VALUE IN TYPE OF FOOD`, y= freq, 
                                      text = glue("Options : {`(B5) RELIGION`} 
                                        Jumlah: {freq}"))) +
            geom_line(aes(group = `(B5) RELIGION`, col = `(B5) RELIGION`)) + 
            geom_point() +
            labs(title = "Determining Religious Value in type of food on Religion",
                 x= "Types",
                 y= "Number of Approval") +
            theme_minimal()
        
        ggplotly(plotf, tooltip = "text")
        
    })
    
    output$plot7 <- renderPlotly({
        
        foodedu <- food %>%
            select(`(B7) EDUCATION LEVEL`,`(E18) RELIGIOUS VALUE IN TYPE OF FOOD`) %>%
            group_by(`(B7) EDUCATION LEVEL`, `(E18) RELIGIOUS VALUE IN TYPE OF FOOD`) %>% 
            summarise(freq = n())
        
        plotg <- ggplot(foodedu, aes(x= `(E18) RELIGIOUS VALUE IN TYPE OF FOOD`, y= freq, 
                                     text = glue("Options : {`(B7) EDUCATION LEVEL`} 
                                        Jumlah: {freq}"))) +
            geom_line(aes(group = `(B7) EDUCATION LEVEL`, col = `(B7) EDUCATION LEVEL`)) + 
            geom_point() +
            labs(title = "Determining Religious Value in type of food on Religion",
                 x= "Types",
                 y= "Number of Approval") +
            theme_minimal()
        
        ggplotly(plotg, tooltip = "text")
        
    })
    
    output$table1 <- DT::renderDataTable({
        datatable(food, options = list(scrollX = T, scrollY = "600px"))
        
    })
    
}

shinyApp(ui, server)
